// defenir valores do combustivel 

const precoGasolina = 6.17;
const precoEtanol = 4.35;
const precoDiesel = 5.60;

// function 
function atualizavalor(){
    let tipo = document.getElementById("combustivel").value;
    console.log(tipo);

let Litros = parseFloat(document.getElementById("Litros").value) ;
let precoporLitro;

switch(tipo){
    case "Gasolina":
        precoporLitro = precoGasolina;
        break;

            case "Etanol":
                precoporLitro = precoEtanol;
                break;

                case "Diesel":
                    precoporLitro = precoDiesel;
                    break;

}

console.log(precoporLitro);
calcularValorAbastecimento(precoporLitro, Litros);
}

let tipoCombustivel =  document.getElementById("combustivel");
tipoCombustivel.addEventListener("change", atualizavalor);

function calcularValorAbastecimento(precoCombustivel, Litros){
    let ValorTotal = precoCombustivel*Litros;
   // document.getElementById("Resultado").textContent = ValorTotal;

   if(Litros <=0 || isNaN(Litros)){
    document.getElementById("Resultado").textContent = "Insira um Valor Valido ";

   }else{
    document.getElementById("Resultado").textContent = `Valor: ${formatarMoeda(ValorTotal)}`;
   }
   
}
let Litros = document.getElementById("Litros");
Litros.addEventListener("input", atualizavalor);

function formatarMoeda(valor){
    return "R$" + valor.toLocaleString("pt-br", {minimumFreactionDigits: 2, maximumFractionDigits: 2});
}

