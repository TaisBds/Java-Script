// buscar o elemento no html


let meuElemento = document.getElementById("paragrafo");
console.log(meuElemento);
// aparece a tag interira 

// aparece apenas o conteudo 
console.log(meuElemento.textContent);

let paragrafo1 = document.getElementsByClassName("paragrafo");
console.log(paragrafo1);

// laço de repetição para percorrer um array 
for( let i = 0; i < paragrafo1.length; i++){
  console.log(paragrafo1[i].textContent);
};
console.log(paragrafo1[2].textContent);


// busca por elementos ex: P 
let paragrafo2 = document.getElementsByTagName("p");
console.log(paragrafo2.textContent);

// criar um elemento no html pelo javaScript
let destino = document.getElementById("elemento");
let p = document.createElement("p");
p.textContent = "Elemento Criado via Js";
destino.append(p);

// criar lista 
let ul = document.createElement("ul");
let itens = ["item 1", "item 2"];
for (let i = 0; i< itens.length; i++){
  let li = document.createElement("li");
  li.textContent = itens[i];
  ul.append(li);
}
destino.append(ul);

// value para receber valor
// função somar()
function somar(){
let n1 = parseFloat (document.getElementById("num1").value);
let n2 = parseFloat (document.getElementById("num2").value);
let soma = n1 + n2;

let saida = `<strong>Resultado: </strong>${soma}`;
document.getElementById("resultado").innerHTML = saida;
}

// botão 

let botao = document.getElementById("botao");
botao.onclick = function(){
  alert("clicou !");
  botao.textContent = "Você Clicou!";
  botao.style.backgroundColor = "blue";
}